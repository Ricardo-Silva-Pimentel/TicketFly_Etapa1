// server.js
const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const asientoRoutes = require('./routes/asientoRoutes');
const clienteRoutes = require('./routes/clienteRoutes');
const eventoRoutes = require('./routes/eventoRoutes');
const productoraRoutes = require('./routes/productoraRoutes');
const ventaRoutes = require('./routes/ventaRoutes');

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Rutas
app.use('/api/asientos', asientoRoutes);
app.use('/api/clientes', clienteRoutes);
app.use('/api/eventos', eventoRoutes);
app.use('/api/productoras', productoraRoutes);
app.use('/api/ventas', ventaRoutes);

// Configurar el puerto
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
});
