
const express = require('express');
const router = express.Router();
const clienteController = require('../controllers/clienteController');

// Ruta para obtener todos los clientes
router.get('/', clienteController.getClientes);

// Ruta para crear un nuevo cliente
router.post('/', clienteController.createCliente);

// Ruta para actualizar un cliente existente
router.put('/:id', clienteController.updateCliente);

// Ruta para eliminar un cliente existente
router.delete('/:id', clienteController.deleteCliente);

module.exports = router;
