
const express = require('express');
const router = express.Router();
const ventaController = require('../controllers/ventaController');

// Ruta para obtener todas las ventas
router.get('/', ventaController.getVentas);

// Ruta para crear una nueva venta
router.post('/', ventaController.createVenta);

// Ruta para actualizar una venta existente
router.put('/:id', ventaController.updateVenta);

// Ruta para eliminar una venta existente
router.delete('/:id', ventaController.deleteVenta);

module.exports = router;
