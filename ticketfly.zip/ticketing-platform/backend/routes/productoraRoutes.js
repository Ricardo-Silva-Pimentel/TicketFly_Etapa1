
const express = require('express');
const router = express.Router();
const productoraController = require('../controllers/productoraController');

// Ruta para obtener todas las productoras
router.get('/', productoraController.getProductoras);

// Ruta para crear una nueva productora
router.post('/', productoraController.createProductora);

// Ruta para actualizar una productora existente
router.put('/:RUN_prod', productoraController.updateProductora);

// Ruta para eliminar una productora existente
router.delete('/:RUN_prod', productoraController.deleteProductora);

module.exports = router;
