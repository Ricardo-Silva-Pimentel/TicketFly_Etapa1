
const express = require('express');
const router = express.Router();
const eventoController = require('../controllers/eventoController');

// Ruta para obtener todos los eventos
router.get('/', eventoController.getEventos);

// Ruta para crear un nuevo evento
router.post('/', eventoController.createEvento);

// Ruta para actualizar un evento existente
router.put('/:id', eventoController.updateEvento);

// Ruta para eliminar un evento existente
router.delete('/:id', eventoController.deleteEvento);

module.exports = router;
