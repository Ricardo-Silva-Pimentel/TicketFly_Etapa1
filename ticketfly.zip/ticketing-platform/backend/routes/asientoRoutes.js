
const express = require('express');
const router = express.Router();
const asientoController = require('../controllers/asientoController');

// Ruta para obtener todos los asientos
router.get('/', asientoController.getAsientos);

// Ruta para crear un nuevo asiento
router.post('/', asientoController.createAsiento);

// Ruta para actualizar un asiento existente
router.put('/:id', asientoController.updateAsiento);

// Ruta para eliminar un asiento existente
router.delete('/:id', asientoController.deleteAsiento);

module.exports = router;
