
const db = require('../config/db');

exports.getEventos = (req, res) => {
  const query = 'SELECT * FROM evento';
  db.query(query, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
};

exports.createEvento = (req, res) => {
  const { RUN_prod, ID_recinto, nombre_evento, fecha, hora_inicio, hora_termino, descripcion } = req.body;
  const query = 'INSERT INTO evento (RUN_prod, ID_recinto, nombre_evento, fecha, hora_inicio, hora_termino, descripcion) VALUES (?, ?, ?, ?, ?, ?, ?)';
  db.query(query, [RUN_prod, ID_recinto, nombre_evento, fecha, hora_inicio, hora_termino, descripcion], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({ id_evento: results.insertId });
  });
};

exports.updateEvento = (req, res) => {
  const { id } = req.params;
  const { RUN_prod, ID_recinto, nombre_evento, fecha, hora_inicio, hora_termino, descripcion } = req.body;
  const query = 'UPDATE evento SET RUN_prod = ?, ID_recinto = ?, nombre_evento = ?, fecha = ?, hora_inicio = ?, hora_termino = ?, descripcion = ? WHERE id_evento = ?';
  db.query(query, [RUN_prod, ID_recinto, nombre_evento, fecha, hora_inicio, hora_termino, descripcion, id], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Evento actualizado con éxito' });
  });
};

exports.deleteEvento = (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM evento WHERE id_evento = ?';
  db.query(query, [id], (err, results) => {
    if (err) {
      if (err.code === 'ER_ROW_IS_REFERENCED_2') {
        return res.status(400).json({ message: 'No se puede eliminar el evento porque tiene tickets asociados.' });
      }
      return res.status(500).json(err);
    }
    res.json({ message: 'Evento eliminado con éxito' });
  });
};
