
const db = require('../config/db');

exports.getProductoras = (req, res) => {
  const query = 'SELECT * FROM productora';
  db.query(query, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
};

exports.createProductora = (req, res) => {
  const { RUN_prod, nombre_prod, nro_ventas, contrasena_prod } = req.body;
  const query = 'INSERT INTO productora (RUN_prod, nombre_prod, nro_ventas, contrasena_prod) VALUES (?, ?, ?, ?)';
  db.query(query, [RUN_prod, nombre_prod, nro_ventas, contrasena_prod], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Productora creada con éxito' });
  });
};

exports.updateProductora = (req, res) => {
  const { RUN_prod } = req.params;
  const { nombre_prod, nro_ventas, contrasena_prod } = req.body;
  const query = 'UPDATE productora SET nombre_prod = ?, nro_ventas = ?, contrasena_prod = ? WHERE RUN_prod = ?';
  db.query(query, [nombre_prod, nro_ventas, contrasena_prod, RUN_prod], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Productora actualizada con éxito' });
  });
};

exports.deleteProductora = (req, res) => {
  const { RUN_prod } = req.params;
  const query = 'DELETE FROM productora WHERE RUN_prod = ?';
  db.query(query, [RUN_prod], (err, results) => {
    if (err) {
      if (err.code === 'ER_ROW_IS_REFERENCED_2') {
        return res.status(400).json({ message: 'No se puede eliminar la productora porque tiene eventos asociados.' });
      }
      return res.status(500).json(err);
    }
    res.json({ message: 'Productora eliminada con éxito' });
  });
};
