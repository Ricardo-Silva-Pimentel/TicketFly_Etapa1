
const db = require('../config/db');

exports.getAsientos = (req, res) => {
  const query = 'SELECT * FROM asiento';
  db.query(query, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
};

exports.createAsiento = (req, res) => {
  const { disponibilidad, ID_recinto } = req.body;
  const query = 'INSERT INTO asiento (disponibilidad, ID_recinto) VALUES (?, ?)';
  db.query(query, [disponibilidad, ID_recinto], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({ id_asiento: results.insertId });
  });
};

exports.updateAsiento = (req, res) => {
  const { id } = req.params;
  const { disponibilidad } = req.body;
  const query = 'UPDATE asiento SET disponibilidad = ? WHERE id_asiento = ?';
  db.query(query, [disponibilidad, id], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Asiento actualizado con éxito' });
  });
};

exports.deleteAsiento = (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM asiento WHERE id_asiento = ?';
  db.query(query, [id], (err, results) => {
    if (err) {
      if (err.code === 'ER_ROW_IS_REFERENCED_2') {
        return res.status(400).json({ message: 'No se puede eliminar el asiento porque está asociado a un ticket.' });
      }
      return res.status(500).json(err);
    }
    res.json({ message: 'Asiento eliminado con éxito' });
  });
};
