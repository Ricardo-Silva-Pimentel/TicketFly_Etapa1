
const db = require('../config/db');

exports.getClientes = (req, res) => {
  const query = 'SELECT * FROM cliente';
  db.query(query, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
};

exports.createCliente = (req, res) => {
  const { Rut_cliente, nombre_cliente, apellido_cliente, contrasena_cliente, cliente_vip, email } = req.body;
  const query = 'INSERT INTO cliente (Rut_cliente, nombre_cliente, apellido_cliente, contrasena_cliente, cliente_vip, email) VALUES (?, ?, ?, ?, ?, ?)';
  db.query(query, [Rut_cliente, nombre_cliente, apellido_cliente, contrasena_cliente, cliente_vip, email], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({ ID_cliente: results.insertId });
  });
};

exports.updateCliente = (req, res) => {
  const { id } = req.params; // ID del cliente a actualizar
  const { nombre_cliente, apellido_cliente, contrasena_cliente, cliente_vip, email } = req.body;
  const query = 'UPDATE cliente SET nombre_cliente = ?, apellido_cliente = ?, contrasena_cliente = ?, cliente_vip = ?, email = ? WHERE ID_cliente = ?';
  db.query(query, [nombre_cliente, apellido_cliente, contrasena_cliente, cliente_vip, email, id], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Cliente actualizado con éxito' });
  });
};

exports.deleteCliente = (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM cliente WHERE ID_cliente = ?';
  db.query(query, [id], (err, results) => {
    if (err) {
      if (err.code === 'ER_ROW_IS_REFERENCED_2') {
        return res.status(400).json({ message: 'No se puede eliminar el cliente porque tiene ventas asociadas.' });
      }
      return res.status(500).json(err);
    }
    res.json({ message: 'Cliente eliminado con éxito' });
  });
};
