
const db = require('../config/db');

exports.getVentas = (req, res) => {
  const query = `
    SELECT venta.*, cliente.nombre_cliente, evento.nombre_evento 
    FROM venta 
    JOIN cliente ON venta.Rut_cliente = cliente.Rut_cliente 
    JOIN evento ON venta.id_evento = evento.id_evento;`;
  db.query(query, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
};

exports.createVenta = (req, res) => {
  const { Rut_cliente, id_evento, total_ventas, cant_ticket } = req.body;
  const query = 'INSERT INTO venta (Rut_cliente, id_evento, total_ventas, cant_ticket) VALUES (?, ?, ?, ?)';
  db.query(query, [Rut_cliente, id_evento, total_ventas, cant_ticket], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({ id_venta: results.insertId });
  });
};

exports.updateVenta = (req, res) => {
  const { id } = req.params; // ID de la venta a actualizar
  const { Rut_cliente, id_evento, total_ventas, cant_ticket } = req.body;
  const query = 'UPDATE venta SET Rut_cliente = ?, id_evento = ?, total_ventas = ?, cant_ticket = ? WHERE id_venta = ?';
  db.query(query, [Rut_cliente, id_evento, total_ventas, cant_ticket, id], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Venta actualizada con éxito' });
  });
};

exports.deleteVenta = (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM venta WHERE id_venta = ?';
  db.query(query, [id], (err, results) => {
    if (err) {
      if (err.code === 'ER_ROW_IS_REFERENCED_2') {
        return res.status(400).json({ message: 'No se puede eliminar la venta porque tiene tickets asociados.' });
      }
      return res.status(500).json(err);
    }
    res.json({ message: 'Venta eliminada con éxito' });
  });
};
